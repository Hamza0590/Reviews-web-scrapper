import streamlit as st
import pandas as pd
import seaborn as sns
from selenium import webdriver
from selenium.webdriver.common.by import By
import json
from datetime import datetime
from selenium.common.exceptions import ElementNotInteractableException, NoSuchElementException
from selenium import webdriver
import time
import matplotlib.pyplot as plt
import numpy as np
from datetime import timedelta

def parse_review_date(review_date_str):
    
    # Check if the date is relative (e.g., 'Dined 2 days ago')
    if 'ago' in review_date_str:
        days_ago = int(review_date_str.split(' ')[1])
        review_date = datetime.now() - timedelta(days=days_ago)
    
    # Check if the date is absolute (e.g., 'Dined on August 12, 2024')
    elif 'on' in review_date_str:
        review_date_str = review_date_str.replace('Dined on ', '')
        review_date = datetime.strptime(review_date_str, "%B %d, %Y")
    
    #print(review_date)
    return review_date

def temp(url, file_path, year, month, day):
    current_date = datetime.now().date()
    months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    date_parts = str(current_date).split('-')

    curr_year, current_month, curr_day = date_parts
    curr_year, current_month, curr_day = int(curr_year), int(current_month), int(curr_day)
    curr_month_name = months[current_month - 1]
    
    format_one = True
    driver = webdriver.Chrome()
    driver.get(url)

    rating = []
    d = []
    element_interact = False
    end = False

    try:
        page_number = 1
        while True:
            retries = 3
            while retries > 0:
                try:
                    time.sleep(2)
                    temp_date = driver.find_elements(By.CLASS_NAME, "iLkEeQbexGs-")
                    temp_food = driver.find_elements(By.CLASS_NAME, "-y00OllFiMo-")
                    
                    for i in range(len(temp_date)):
                        t1 = temp_date[i].text
                        t1 = parse_review_date(t1)
                        date = temp_date[i].text.split(' ')
                        print(f"Date parts: {t1}")
                        if date[2] not in months:
                                print("Month not in date")
                                if (abs(curr_day - int(date[1])) < int(day) and month==curr_month_name):
                                    end = True
                                    break
                                else:
                                    rating.append(temp_food[i * 4].text)
                                    d.append(t1)
                        else:
                            a = date[3]
                            if len(a)>2:
                                temp_day = int(a[0:2])
                            else:
                                temp_day = int(a[0])
                            temp_month = date[2]
                            temp_year = int(date[4])
                            print("Month is in date")
                            if int(year) == temp_year and month == temp_month and int(day) > temp_day:
                                end = True
                                break
                            rating.append(temp_food[i * 4].text)
                            d.append(t1)
                        
                    if end == True:
                        break

                    retry = 3
                    while retry > 0:
                        forward_button = driver.find_element(By.CSS_SELECTOR, "#reviews > section > footer > div > div:nth-child(3) > a > div > span > svg")
                        if forward_button.is_enabled() and retry > 0:
                            forward_button.click()
                            time.sleep(3)
                            driver.execute_script("window.scrollTo(0, 1200)")
                            break
                        else:
                            retry -= 1

                    page_number += 1
                    break
                except ElementNotInteractableException:
                    element_interact = True
                    break
                except Exception as e:
                    print("jee oyee")
                    driver.refresh()
                    retries -= 1
            
            if element_interact:
                break

            df = pd.DataFrame({"Rating": rating , "Date":d})
            df.to_csv(file_path, sep=',', index=False, header=True, encoding=None)
            if end == True:
                break

    finally:
        print("No more pages to process.")
        driver.quit()
st.markdown("""<h1 style="color: #ff6f61; text-align: center; font-size: 28px; margin-top: 20px; margin-bottom: 10px;font-family: 'Arial, sans-serif';">🔍 Review Analysis</h1><hr style="border: none; height: 2px; background-color: #ff6f61; margin-bottom: 20px;">""", unsafe_allow_html=True)
st.sidebar.markdown("""<div style="background-color: #2c2f33; padding: 20px; border-radius: 12px; border: 1px solid #23272a; margin-bottom: 20px;"><h2 style="color: #7289da; margin-bottom: 15px; font-size: 20px; text-align: center;">🔍 Review Sidebar</h2><p style="color: #99aab5; text-align: center; font-size: 14px; margin-bottom: 10px;">Choose an option to navigate through the reviews:</p></div>""", unsafe_allow_html=True)

n = st.sidebar.selectbox(
    "Select an option:",
    ["", "🍽️ Food Reviews", "🛎️ Service Reviews", "⭐ Overall Reviews", "📊 Competitor Analysis"]
)

if n=="🍽️ Food Reviews":

    with open("model_rev.json", "r") as file:
        data = json.load(file)
    review_num = 15
    total_pages = (len(data) + 1) // review_num
    page_number = st.number_input("Select Page:" ,  min_value=1, max_value= total_pages,step=1,value=1)

    start_index =(page_number -1) * review_num
    end_index= start_index +review_num
    st.write(f"### Page {page_number}/{total_pages}")

    for i, rev in enumerate(data[start_index:end_index], start=1):
        temp = json.loads(rev)
        if not temp["food"]:
            st.markdown(f"""<div style="border: 2px solid #d9534f; padding: 10px; border-radius: 6px; background-color: #f9d6d5; margin-bottom: 10px;"><h4 style="color: #d9534f;">🍽️ Review {start_index + i}</h4><p style="font-size: 16px; color: #a94442; font-weight: bold;">No review about food.</p></div>""", unsafe_allow_html=True)
        else:
            st.markdown(f"""<div style="border: 2px solid #5bc0de; padding: 10px; border-radius: 6px; background-color: #d9edf7; margin-bottom: 10px;"><h4 style="color: #5bc0de;">🍽️ Review {start_index + i}</h4><p style="font-size: 16px; color: #31708f;">Food Review:</p><p style="font-size: 16px; color: #31708f; font-weight: bold;">{temp['food']}</p></div>""", unsafe_allow_html=True)



elif n== "🛎️ Service Reviews":
    with open("model_rev.json", "r") as file:
        data = json.load(file)
    review_num = 15
    total_pages = (len(data) + 1) // review_num
    page_number = st.number_input("Select Page:" ,  min_value=1, max_value= total_pages,step=1,value=1)

    start_index =(page_number -1) * review_num
    end_index= start_index +review_num
    st.write(f"### Page {page_number}/{total_pages}")

    for i, rev in enumerate(data[start_index:end_index], start=1):
        temp = json.loads(rev)
        if not temp["service"]:
            st.markdown(f"""<div style="border: 2px solid #d9534f; padding: 10px; border-radius: 6px; background-color: #f9d6d5; margin-bottom: 10px;"><h4 style="color: #d9534f;">🍽️ Review {start_index + i}</h4><p style="font-size: 16px; color: #a94442; font-weight: bold;">No review about Service.</p></div>""", unsafe_allow_html=True)
        else:
            st.markdown(f"""<div style="border: 2px solid #5bc0de; padding: 10px; border-radius: 6px; background-color: #d9edf7; margin-bottom: 10px;"><h4 style="color: #5bc0de;">🍽️ Review {start_index + i}</h4><p style="font-size: 16px; color: #31708f;">Service Review:</p><p style="font-size: 16px; color: #31708f; font-weight: bold;">{temp['service']}</p></div>""", unsafe_allow_html=True)

elif n == "⭐ Overall Reviews":
    data = pd.read_csv("Review.csv")
    reviews = data["Reviews"]
    review_num = 10
    total_pages = (len(reviews) + review_num - 1) // review_num
    page_number = st.number_input("Select Page:", min_value=1, max_value=total_pages, step=1, value=1)

    start_index = (page_number - 1) * review_num
    end_index = start_index + review_num
    st.write(f"### Page {page_number}/{total_pages}")

    rating = data["Rating"]
    food = data["Food"]
    service = data["Service"]
    ambiance = data["Ambiance"]

    for i, (review, rating_val, f, s, a) in enumerate(zip(reviews[start_index:end_index],rating[start_index:end_index],food[start_index:end_index],service[start_index:end_index],ambiance[start_index:end_index]), start=1):
        st.markdown(f"""<div style="border: 1px solid #ddd; padding: 15px; border-radius: 8px; margin-bottom: 15px;"><h4 style="color: #ff6f61; margin-bottom: 10px;">🍽️ Review {start_index + i}</h4><p style="font-size: 16px; margin-bottom: 15px; line-height: 1.5; color: #333;">{review}</p><div style="display: flex; justify-content: space-between; font-size: 14px; color: #444;"><div>⭐ Rating: <span style="color: #007bff; font-weight: bold;">{rating_val}/5</span></div><div>🍴 Food: <span style="color: #007bff; font-weight: bold;">{f}/5</span></div><div>🛎️ Service: <span style="color: #007bff; font-weight: bold;">{s}/5</span></div><div>🎶 Ambiance: <span style="color: #007bff; font-weight: bold;">{a}/5</span></div></div></div>""", unsafe_allow_html=True)


elif n =="📊 Competitor Analysis":
    st.markdown("<h2 style='color: #ff6f61;'>📊 Competitor Analysis Input Form</h2>", unsafe_allow_html=True)
    st.markdown("<p style='font-size: 16px;'>Select the year for the analysis:</p>", unsafe_allow_html=True)
    year = st.number_input("Year",min_value=2023,max_value=2024,value=2024,help="Choose the year within the range 2023-2024.")
    st.markdown("<p style='font-size: 16px;'>Select the month:</p>", unsafe_allow_html=True)
    months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    month = st.selectbox("Month",months,help="Choose the month for the analysis.")

    st.markdown("<p style='font-size: 16px;'>Enter the day:</p>", unsafe_allow_html=True)
    day = st.number_input("Day",min_value=1,max_value=31,value=1,help="Enter a valid day between 1 and 31.")
    st.markdown("<p style='font-size: 16px;'>Enter the URLs of the restaurants:</p>", unsafe_allow_html=True)
    url1 = st.text_input("Restaurant 1 URL",placeholder="Enter the URL of the first restaurant...",help="Provide the URL of the first restaurant for review comparison.")
    url2 = st.text_input("Restaurant 2 URL",placeholder="Enter the URL of the second restaurant...",help="Provide the URL of the second restaurant for review comparison.")
    if st.button("🔍 Start Analysis"):
        with st.spinner('Fetching Data and Processing Ratings...'):
            #temp(url1 , "rating_one.csv" , year , month , day)
            #temp(url2 , "rating_two.csv" , year , month , day)
            df1 = pd.read_csv("rating_one.csv")
            df2 = pd.read_csv("rating_two.csv")
            df1['Date'] = pd.to_datetime(df1['Date'])
            df2['Date'] = pd.to_datetime(df2['Date'])
            df1['Date'] = df1['Date'].dt.date
            df2['Date'] = df2['Date'].dt.date
            df1['Restaurant'] = 'Restaurant 1'
            df2['Restaurant'] = 'Restaurant 2'
        st.header("Time Series Graph: ") 
        fig, g = plt.subplots(figsize=(10, 6))
        g.plot(df1['Date'], df1['Rating'], marker='o', label='Restaurant 1', color='b')
        g.plot(df2['Date'], df2['Rating'], marker='o', label='Restaurant 2', color='r')
        g.set_title('Competitor Analysis: Ratings Over Time')
        g.set_ylabel('Ratings')
        g.set_xlabel('Time Duration')
        g.legend()


        st.pyplot(fig)
        fig, ax = plt.subplots(figsize=(8, 6))
        all_ratings = pd.concat([df1[['Rating', 'Date', 'Restaurant']], df2[['Rating', 'Date', 'Restaurant']]])
        average_ratings = all_ratings.groupby('Restaurant')['Rating'].mean().reset_index()
        sns.barplot(data=average_ratings, x='Restaurant', y='Rating', palette='Set2', ax=ax)
        ax.set_ylabel("Average Rating")
        ax.set_xlabel("Restaurant")
        st.pyplot(fig)


        fig, ax = plt.subplots(figsize=(8, 6))
        sns.boxplot(data=all_ratings, x='Restaurant', y='Rating', ax=ax, palette='Set2')
        ax.set_xlabel("Restaurant")
        ax.set_ylabel("Rating")
        st.pyplot(fig)


        # 6. Overall Summary Text
        st.info("## Final Review: Restaurant Comparison")
        avg_1 = df1['Rating'].mean()
        avg_2 = df2['Rating'].mean()
        st.write(f"**Average Rating**: Restaurant 1: {avg_1} | Restaurant 2: {avg_2}")
        if avg_2 < avg_1:
            st.write("**Conclusion**: Restaurant 1 has higher average ratings. It seems to be a more favored choice overall.")
        elif avg_2 > avg_1:
            st.write("**Conclusion**: Restaurant 2 has higher average ratings. It might be receiving more favorable reviews.")
        else:
            st.write("**Conclusion**: Both restaurants have similar average ratings.")
        